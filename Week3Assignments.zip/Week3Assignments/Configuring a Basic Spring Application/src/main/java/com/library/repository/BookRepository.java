package com.library.repository;

public class BookRepository {
    public String getBook() {
        return "Spring in Action";
    }
}
