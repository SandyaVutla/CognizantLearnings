package com.library.repository;
public class BookRepository {
    public void displayBooks() {
        System.out.println("Displaying all books from the repository.");
    }
}
